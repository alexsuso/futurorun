
import React from 'react';
import { 
  House, 
  ChartLineUp, 
  MapTrifold, 
  User, 
  Pulse 
} from "@phosphor-icons/react";

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'home', icon: <House size={24} />, label: 'Inicio' },
    { id: 'training', icon: <Pulse size={24} />, label: 'Plan' },
    { id: 'progress', icon: <ChartLineUp size={24} />, label: 'Futuro' },
    { id: 'routes', icon: <MapTrifold size={24} />, label: 'Rutas' },
    { id: 'profile', icon: <User size={24} />, label: 'Perfil' },
  ];

  return (
    <div className="min-h-screen pb-24 max-w-md mx-auto bg-[#050505] border-x border-gray-900 overflow-x-hidden">
      <header className="p-6 sticky top-0 bg-[#050505]/80 backdrop-blur-md z-50 border-b border-gray-800">
        <div className="flex justify-between items-center">
          <h1 className="font-futuristic text-2xl font-bold tracking-tighter text-cyan-400 neon-text-cyan">
            FUTURORUN
          </h1>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-purple-600 animate-pulse neon-border" />
        </div>
      </header>

      <main className="p-4">
        {children}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-[#0a0a0a]/90 backdrop-blur-xl border-t border-gray-800 px-6 py-4 z-50">
        <div className="flex justify-between items-center">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 transition-all duration-300 ${
                activeTab === tab.id ? 'text-cyan-400 scale-110' : 'text-gray-500'
              }`}
            >
              {tab.icon}
              <span className="text-[10px] font-bold uppercase tracking-widest">{tab.label}</span>
              {activeTab === tab.id && (
                <div className="w-1 h-1 rounded-full bg-cyan-400 mt-0.5 shadow-[0_0_5px_cyan]" />
              )}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default Layout;
