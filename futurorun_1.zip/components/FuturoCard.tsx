
import React from 'react';
import { Robot } from "@phosphor-icons/react";

interface FuturoCardProps {
  prediction: string;
  loading: boolean;
}

const FuturoCard: React.FC<FuturoCardProps> = ({ prediction, loading }) => {
  return (
    <div className="relative overflow-hidden rounded-2xl p-6 bg-gradient-to-br from-purple-900/20 to-cyan-900/10 border border-purple-500/30">
      <div className="absolute top-0 right-0 p-4 opacity-10">
        <Robot size={120} weight="thin" />
      </div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
            <Robot size={24} weight="fill" />
          </div>
          <h3 className="font-futuristic text-sm tracking-widest text-purple-400 uppercase">Análisis Predictivo</h3>
        </div>

        {loading ? (
          <div className="space-y-3 animate-pulse">
            <div className="h-4 bg-gray-800 rounded w-3/4" />
            <div className="h-4 bg-gray-800 rounded w-full" />
            <div className="h-4 bg-gray-800 rounded w-5/6" />
          </div>
        ) : (
          <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-wrap italic">
            "{prediction}"
          </p>
        )}

        <div className="mt-6 flex gap-4">
          <div className="flex-1 bg-black/40 rounded-xl p-3 border border-gray-800">
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Est. 5K</p>
            <p className="font-futuristic text-lg text-cyan-400">24:15</p>
          </div>
          <div className="flex-1 bg-black/40 rounded-xl p-3 border border-gray-800">
            <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">Est. 10K</p>
            <p className="font-futuristic text-lg text-purple-400">51:30</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FuturoCard;
