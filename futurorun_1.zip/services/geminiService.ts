
import { GoogleGenAI, Type } from "@google/genai";
import { UserProfile, WeeklyPlan, RunRecord } from "../types";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTrainingPlan = async (profile: UserProfile): Promise<WeeklyPlan> => {
  const prompt = `Actúa como un entrenador olímpico. Crea un plan de entrenamiento de 1 semana para un corredor con los siguientes datos:
    Edad: ${profile.age}, Peso: ${profile.weight}kg, Nivel: ${profile.level}, Objetivo: ${profile.goal}.
    Incluye 7 días. Usa tipos de sesión: 'Smooth', 'Intervals', 'Tempo', 'Rest', 'Long Run'.
    Devuelve un JSON con el formato: { "weekNumber": 1, "sessions": [{ "day": "Lunes", "type": "...", "description": "...", "durationMinutes": 45, "targetPace": "5:30" }] }`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          weekNumber: { type: Type.NUMBER },
          sessions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.STRING },
                type: { type: Type.STRING },
                description: { type: Type.STRING },
                durationMinutes: { type: Type.NUMBER },
                targetPace: { type: Type.STRING },
              },
              required: ["day", "type", "description", "durationMinutes"]
            }
          }
        },
        required: ["weekNumber", "sessions"]
      }
    }
  });

  // Access the text property directly, not as a function.
  return JSON.parse(response.text);
};

export const getFuturoPrediction = async (history: RunRecord[], profile: UserProfile): Promise<string> => {
  if (history.length === 0) return "Sigue corriendo para que el Modo Futuro pueda analizar tu rendimiento.";
  
  const historyText = history.slice(-5).map(r => `${r.distanceKm}km en ${r.averagePace}`).join(', ');
  const prompt = `Como analista de datos deportivos, analiza estos últimos entrenamientos: ${historyText}.
    Perfil: ${profile.goal}. Predice de forma realista y motivadora (con un tono futurista) qué tiempos podría alcanzar este corredor en 5K y 10K si mantiene la constancia las próximas 4 semanas.
    Sé breve, usa iconos futuristas y lenguaje directo. Máximo 100 palabras.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
  });

  // Access the text property directly, not as a function.
  return response.text;
};
